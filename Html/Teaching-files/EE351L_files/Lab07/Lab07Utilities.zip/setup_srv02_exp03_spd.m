%% SETUP_SRV02_EXP03_SPD
%
% Sets the necessary parameters to run the SRV02 Experiment #2: Position
% Control laboratory using the "s_srv02_pos" and "q_srv02_pos" Simulink 
% diagrams.
% 
% Copyright (C) 2007 Quanser Consulting Inc.
%
clear all;
%
%% SRV02 Configuration
% External Gear Configuration: set to 'HIGH' or 'LOW'
EXT_GEAR_CONFIG = 'LOW';
% Encoder Type: set to 'E' or 'EHR'
ENCODER_TYPE = 'E';
% Is SRV02 equipped with Tachometer? (i.e. option T): set to 'YES' or 'NO'
TACH_OPTION = 'YES';
% Type of Load: set to 'NONE', 'DISC', or 'BAR'
LOAD_TYPE = 'DISC';
% Cable Gain used: set to 1, 3, or 5
K_CABLE = 1;
% Universal Power Module (UPM) Type: set to 'UPM_1503' or 'UPM_2405'
UPM_TYPE = 'UPM_1503';
% Digital-to-Analog Maximum Voltage (V)
VMAX_DAC = 10;
%
%% Lab Configuration
% Type of controller: set it to 'AUTO', 'MANUAL'
CONTROL_TYPE = 'AUTO';
% CONTROL_TYPE = 'MANUAL';
%
%% PI Specifications
% Peak time (s)
tp = 0.05;
% Percentage overshoot (%)
PO = 5;
% Steady-state error (rad)
e_ss = 0.0;
%
%% Control Specifications of Compensated Open-Loop System
% Desired crossover frequeny (rad/s)
w_g_des = 75.0;
% Desired phase margin (deg)
PM_des = 75.0;
%
%% SRV02 System Parameters
% Set Model Variables Accordingly to the USER-DEFINED SRV02 System Configuration
% Also Calculate the SRV02 Model Parameters and 
% Write them to the MATLAB Workspace (to be used in Simulink diagrams)
[ Rm, kt, km, Kg, eta_g, Beq, Jm, Jeq, eta_m, K_POT, K_TACH, K_ENC, VMAX_UPM, IMAX_UPM ] = config_srv02( EXT_GEAR_CONFIG, ENCODER_TYPE, TACH_OPTION, UPM_TYPE, LOAD_TYPE );
%
%% Filter Parameters
% Encoder high-pass filter used to compute velocity
% Cutoff frequency (rad/s)
wcf_e = 2 * pi * 25.0;
wcf = 2 * pi * 50.0;
% Damping ratio
zetaf_e = 0.9;
zetaf = 0.9;
%
%% Calculate Control Gains
if strcmp ( CONTROL_TYPE , 'MANUAL' )
    % Load model parameters based on SRV02 configuration.
    [ K, tau ] = d_model_param(Rm, kt, km, Kg, eta_g, Beq, Jeq, eta_m);
    % Proportional gain (V/rad)
    kp = 0;
    % Integral gain (V/rad/s)
    ki = 0;
    % Set-point weight
    bsp = 0;
    % Lead Compensator
    a = 1;
    T = 1;
    % Lead proportional gain (V/rad/s)
    Kc = 0;
elseif strcmp ( CONTROL_TYPE , 'AUTO' )
    % Load model parameters based on SRV02 configuration.
    [ K, tau ] = d_model_param(Rm, kt, km, Kg, eta_g, Beq, Jeq, eta_m);
    % Calculate PI control gains given specifications.
    [ kp, ki ] = d_pi_design( K, tau, PO, tp );
    % Set-point weight
    bsp = 0;
    % Lead Compensator
    d_lead;
end
%
%% Display
disp( ' ' );
disp( 'SRV02 model parameters: ' );
disp( [ '   K = ' num2str( K, 3 ) ' rad/s/V' ] );
disp( [ '   tau = ' num2str( tau, 3 ) ' s' ] );
disp( 'PI control gains: ' );
disp( [ '   kp = ' num2str( kp, 3 ) ' V/rad' ] );
disp( [ '   ki = ' num2str( ki, 3 ) ' V/rad/s' ] );
disp( 'Lead compensator parameters: ' );
disp( [ '   Kc = ' num2str( Kc, 3 ) ' V/rad/s' ] );
disp( [ '   1/(a*T) = ' num2str( 1/(a*T), 3 ) ' rad/s' ] );
disp( [ '   1/T = ' num2str( 1/T, 3 ) ' rad/s' ] );