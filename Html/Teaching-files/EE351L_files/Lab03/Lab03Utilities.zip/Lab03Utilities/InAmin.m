function figNumber=inamin(namestr)
%InAmin Initializes a figure for Simulink animations.


if (nargin == 0)
  namestr = 'Simulink Animation';
end

[existFlag,figNumber]=figflag(namestr);
    
if ~existFlag,
  % Now initialize the whole figure...
  position=get(0,'DefaultFigurePosition');
  position(3:4)=[400 300];
  figNumber=figure( ...
       'Name',namestr, ...
       'NumberTitle','off', ...
       'BackingStore','off', ...
       'Position',position);
  axes( ...
       'Units','normalized', ...
       'Position',[0.05 0.1 0.70 0.9], ...
       'Visible','off', ...
       'DrawMode','fast');

end

cla reset;
set(gca,'DrawMode','fast');
axis off;
