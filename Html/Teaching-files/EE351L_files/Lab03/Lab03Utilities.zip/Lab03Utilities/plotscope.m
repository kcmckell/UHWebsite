% plotscope script file captures the scope plot and produces a Figure plot
% It also changes the yellow scope trace to blue. 
% H. Saadat 2002

set(0,'ShowHiddenHandles','on')
disp('Click on the Scope figure (outside the plot area) and hit return')
pause
h(1)=findobj(gcf,'type','axes');
fig=figure;
h(2)=copyobj(h(1), fig);
set(gca,'units','norm','pos',[0.13 0.11 0.775 0.8150])
set(gcf,'paperpositionmode','auto')
hL=findobj(gcf,'type','line'); n=length(hL);
set(0,'ShowHiddenHandles','off')
set(h(2), 'Color',[1 1 1], 'XColor',[0 0 0], 'YColor',[0 0 0])
if n==4
    set(hL(1), 'Color',[1 0 0])
    set(hL(2), 'Color',[0 0 1])
    set(hL(3), 'Color',[1 0 1])
    set(hL(4), 'Color',[0 1 1])
elseif n==3
    set(hL(1), 'Color',[1 0 0])
    set(hL(2), 'Color',[0 0 1])
    set(hL(3), 'Color',[1 0 1])
elseif n==2
    set(hL(1), 'Color',[1 0 0])
    set(hL(2), 'Color',[0 0 1]) 
elseif n==1
    set(hL(1), 'Color',[0 0 1])
else, end
