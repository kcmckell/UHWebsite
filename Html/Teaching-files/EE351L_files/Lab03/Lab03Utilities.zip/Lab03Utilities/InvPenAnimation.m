xx=[]; yy=[];
n=length(theta);
for k=1:n
y1(k)=-.05;
z(k)=y1(k)-0.45;
x1(k)=x(k);
y2(k)=cos(theta(k));
x2(k)=sin(theta(k))+x1(k);
end
h0 = figure('Units','normalized', ...
    'Color',[0.8 0.8 0.8], ...
	'Position',[.6, .6, .2, .2], ...
	'Resize', 'off',...
    'Name',[gcs,' Inverted Pendulum'], ...
	'MenuBar', 'non', 'NumberTitle', 'off',...
    'ToolBar','none');
hpen=line([x1(1), x2(1)], [y1(1), y2(1)], 'erasemode', 'xor' ,'Color', [1  0  0], 'linewidth', 5);
hcart=line([x1(1)-0.15, x1(1)+ 0.15], [z(k), z(k)], 'erasemode', 'xor' ,'Color', [0  1  0], 'linewidth', 60);
axis([-.2  .4 -.8 1.2]);
axis off
for k=2:n
    set(hpen, 'xdata', [x1(k), x2(k)], 'ydata', [y1(k), y2(k)]);
    set(hcart, 'xdata', [x1(k)-.15, x1(k)+ 0.15], 'ydata', [z(k), z(k)]);
    drawnow
    pause(.05)
end
