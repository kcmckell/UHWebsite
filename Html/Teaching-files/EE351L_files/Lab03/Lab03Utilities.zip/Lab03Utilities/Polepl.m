syms s k1 k2 k3 k4
M = 4;  m = 0.2;  g =9.81;  L =.5;
A = [	0		1	0	0  
    (M+m)/(M*L)*g	0	0	0 
                  	0		0	0	1
       	-m/M*g		0	0	0]  
B = [0;        	   -1/(L*M);	0;	1/M],   % Column vector  
C = eye(4),                                 % Identity matrix
D = zeros(4, 1)                             % Column vector
x_0 = [0.1  0  0.1  0]
sI = s*eye(4);
Af = sI-A+B*[k1, k2, k3, k4]
det(Af)

P =[-2+j*.5,  -2-j*.5,  -5,  -4];     % Desired location of the closed loop poles
